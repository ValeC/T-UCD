var aValServices = angular.module('UCD_Methods', []);

var apiKeyString = "EZaocWcSRDd36ZuShAsXENRQuzXF8MM7";

function UCD_MethodsNavigationController($scope, $http) {

	$scope.project_id = getUrlVar("projectID");
	$scope.project = null;
	$scope.projectMethods = null;
	$scope.proj = null;
    $scope.projspos = -1;
    
     
      // get projects
        $scope.getProject = function ()
        {
            var getList = $http.get('https://api.mongolab.com/api/1/databases/timeman/collections/Projects/' + 
                          $scope.project_id, 
                           {
                    			params : { apiKey : apiKeyString }
                			} 
            );
            getList.success(function(data, status, headers, config) {
                $scope.project = data;
                
            });
            getList.error(function(data, status, headers, config) {
               throw new Error("Something got wrong with get");
            });

        };
		
		$scope.getProject();

		$scope.getMethods = function ()
        {
            var getList = $http.get("https://api.mongolab.com/api/1/databases/timeman/collections/UCD_Methods",
            	{ params : 
            	   { apiKey : apiKeyString,
            	     q : JSON.stringify({ "project_id" : "52aee85ae4b01e4b6836c226"})
            	   }
            	}
            	//EZaocWcSRDd36ZuShAsXENRQuzXF8MM7&q={project_id:52aee85ae4b01e4b6836c226}", {} 
                 


                 //+ apiKeyString + '&q={"project_id":"' + $scope.project_id + '"}', {}

            );
            getList.success(function(data, status, headers, config) {
                $scope.projectMethods = data;
                
            }); 
            getList.error(function(data, status, headers, config) {
               throw new Error("Something got wrong with get");
            });
        };

		$scope.getMethods();


        function getUrlVar(key){
			var result = new RegExp(key + "=([^&]*)", "i").exec(window.location.search);
			return result && unescape(result[1]) || "";
		}

	}