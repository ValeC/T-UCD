// Create a module for our core AMail services
var aValServices = angular.module('ProjectsHomepage', []);

var apiKeyString = "EZaocWcSRDd36ZuShAsXENRQuzXF8MM7";

// Some fake projects
var projs = [{
    id: Math.uuid(), 
    project_name: 'Test project'
}, {
    id: Math.uuid(), 
    project_name: 'Simboat'
}, {
    id: Math.uuid(), 
    project_name: 'Smarlies'
}];

function DetailControllerProject($scope, $http) {
    $scope.projects = null;
    $scope.proj = null;
    $scope.projspos = -1;
    $scope.mode = 'default';
    $scope.AddProject = function () {

        //if message already exists
        if ($scope.proj.id != null && $scope.projpos != -1) {
            //substitute it with the old one
            $scope.projects.splice($scope.projpos, 1, $scope.proj);
        }

        //else, create a new one
        else {
            $scope.proj.id = Math.uuid();
            $scope.projects.push($scope.proj);
        }

        //after adding, reset the form
        $scope.proj = null;
        $scope.projpos = -1;
        $scope.projForm.$setPristine();
    };

    $scope.EditProject = function (proj) {

        //when selecting message, put it in the form
        if (proj != null) {
            $scope.proj = JSON.parse(JSON.stringify(proj));

            //$scope.projpos = $scope.projects.indexOf(proj);
            $scope.mode = 'edit';
        }
        else {
            $scope.proj = null;
            $scope.projpos = -1;
        }
        $scope.projForm.$setPristine();
    };

    
    $scope.DeleteProject = function (proj) {
            $scope.proj = proj;

            //if the project exists
            if ($scope.proj._id != null && $scope.projpos != -1) {

                $scope.deleteDialog();  
            }
            
        };

    $scope.NewOrUpdateProject = function () {

        if ($scope.mode == 'edit'){
            $scope.updateProject($scope.proj);
        }

        else{
            $scope.saveProject($scope.proj);
            
        }
        $scope.mode = 'default';
        $scope.proj = null;
        $scope.projpos = -1;
        $scope.projForm.$setPristine();
        
    };

    //we can add and delete the message if: the form is valid (why??), not dirty?? and it exists
    $scope.canDelete = function () {
        return $scope.projForm.$valid && !$scope.projForm.$dirty && $scope.proj != null;
    }
    $scope.canAdd = function () {
        return $scope.projForm.$valid && $scope.projForm.$dirty && $scope.proj != null;
    }

    // get projects
        $scope.getProjects = function ()
        {
            var getList = $http.get('https://api.mongolab.com/api/1/databases/timeman/collections/Projects',
                { params: { apiKey: apiKeyString } }
            );
            getList.success(function(data, status, headers, config) {
                $scope.projects = data;
                
            });
            getList.error(function(data, status, headers, config) {
               throw new Error("Something got wrong with get");
            });
        };

        $scope.getProjects();

        $scope.saveProject = function(project) {
        // add a project
        //if (project == undefined) { project = countryToAdd ; };
        var addThis = $http.post("https://api.mongolab.com/api/1/databases/timeman/collections/Projects",
            project,
            { params : { apiKey : apiKeyString }}
        );
        addThis.success(function(data, status, headers, config) {
            $scope.getProjects();
        });
        addThis.error(function(data, status, headers, config) {
            throw new Error("Something got wrong with save");
        });
    };

     $scope.updateProject = function(project) {
        // add a project
        //if (project == undefined) { project = countryToAdd ; };
        var addThis = $http.put("https://api.mongolab.com/api/1/databases/timeman/collections/Projects",
            project,
            { params : { apiKey : apiKeyString }}
        );
        addThis.success(function(data, status, headers, config) {
            $scope.getProjects();
        });
        addThis.error(function(data, status, headers, config) {
            throw new Error("Something got wrong with update");
        });
    };

         // delete a project
        $scope.deleteProject = function() {
            //if (project == undefined) { project = $scope.countries[1] };
            var delThis = $http.delete('https://api.mongolab.com/api/1/databases/timeman/collections/Projects/' +
                $scope.proj._id.$oid,
                {
                    params : { apiKey : apiKeyString }
                }
            );
            delThis.success(function(data, status, headers, config) {
                $scope.getProjects();
            });
            delThis.error(function(data, status, headers, config) {
                throw new Error("Something got wrong with delete");
            });
        };

        $scope.deleteDialog = function() {
            $( "#dialog-confirm" ).dialog({
                resizable: false,
                height: 160,
                modal: true,
                buttons: {
                    Delete: function() {
                        $scope.deleteProject();
                        $scope.proj = null;
                        $scope.projpos = -1;
                        $scope.projForm.$setPristine();
                        $( this ).dialog( "close" );
                    },
                    Cancel: function() {
                        $( this ).dialog( "close" );
                     
                    }
            }
        });
      };




}

