// Create a module for our core AMail services
var aValServices = angular.module('ProjectsHomepage', []);

var apiKeyString = "EZaocWcSRDd36ZuShAsXENRQuzXF8MM7";

// Some fake projects
var projs = [{
    id: Math.uuid(), 
    project_name: 'Test project'
}, {
    id: Math.uuid(), 
    project_name: 'Simboat'
}, {
    id: Math.uuid(), 
    project_name: 'Smarlies'
}];

function DetailControllerProject($scope, $http) {
    $scope.projects = null;
    $scope.proj = null;
    $scope.projspos = -1;
    $scope.mode = 'default';
    $scope.AddProject = function () {

        //if project already exists
        if ($scope.proj.id != null && $scope.projpos != -1) {
            //substitute it with the old one
            $scope.projects.splice($scope.projpos, 1, $scope.proj);
        }

        //else, create a new one
        else {
            $scope.proj.id = Math.uuid();
            $scope.projects.push($scope.proj);
        }

        //after adding, reset the form
        $scope.proj = null;
        $scope.projpos = -1;
        $scope.projForm.$setPristine();
    };

    $scope.UpdateProject = function (proj) {

        //when selecting message, put it in the form
        if (proj != null) {
            $scope.proj = JSON.parse(JSON.stringify(proj));

            //$scope.projpos = $scope.projects.indexOf(proj);
            $scope.mode = 'update';

        }
        else {
            $scope.proj = null;
            $scope.projpos = -1;
        }
        $scope.projForm.$setPristine();
    };

    
    $scope.DeleteProject = function (proj) {
            $scope.proj = proj;

            //if the project exists
            if ($scope.proj._id != null && $scope.projpos != -1) {

                $scope.deleteDialog();  
            }
            
        };

    $scope.NewOrUpdateProject = function () {

        if ($scope.mode == 'update'){
            $scope.updateProject($scope.proj);
        }

        else{
            $scope.saveProject($scope.proj);
            
        }

        
        
    };

    //we can add and delete the message if: the form is valid (why??), not dirty?? and it exists
    $scope.canDelete = function () {
        return $scope.projForm.$valid && !$scope.projForm.$dirty && $scope.proj != null;
    }
    $scope.canAdd = function () {
        return $scope.projForm.$valid && $scope.projForm.$dirty && $scope.proj != null;
    }

//connection with Mongo DB



    // get projects
        $scope.getProjects = function ()
        {
            var getList = $http.get('https://api.mongolab.com/api/1/databases/timeman/collections/Projects',
                { params: { apiKey: apiKeyString } }
            );
            getList.success(function(data, status, headers, config) {
                $scope.projects = data;
                
            });
            getList.error(function(data, status, headers, config) {
               throw new Error("Something got wrong with get");
            });
        };

        $scope.getProjects();

        $scope.saveProject = function(proj) {
        // add a project
        //if (project == undefined) { project = countryToAdd ; };
        var addThis = $http.post("https://api.mongolab.com/api/1/databases/timeman/collections/Projects",
            proj,
            { params : { apiKey : apiKeyString }}
        );
        addThis.success(function(data, status, headers, config) {
            $scope.go(data._id.$oid);

            //$scope.getProjects();

        });
        addThis.error(function(data, status, headers, config) {
            throw new Error("Something got wrong with save");
        });
    };

     $scope.updateProject = function(proj) {
        // add a project
        //if (project == undefined) { project = countryToAdd ; };
        var addThis = $http.put("https://api.mongolab.com/api/1/databases/timeman/collections/Projects/" + $scope.proj._id.$oid,
            { "name": proj.name },
            { params : { apiKey : apiKeyString }}
        );
        addThis.success(function(data, status, headers, config) {
            $scope.getProjects();
            $scope.projForm.$setPristine();

        });
        addThis.error(function(data, status, headers, config) {
            throw new Error("Something got wrong with update");
        });


    };

         // delete a project
        $scope.deleteProject = function() {
            //if (project == undefined) { project = $scope.projects[1] };
            var delThis = $http.delete('https://api.mongolab.com/api/1/databases/timeman/collections/Projects/' +
                $scope.proj._id.$oid,
                {
                    params : { apiKey : apiKeyString }
                }   
            );
            delThis.success(function(data, status, headers, config) {
                $scope.getProjects();
                return true;
            });
            delThis.error(function(data, status, headers, config) {
                throw new Error("Something got wrong with delete");
                return false;
            });
        };



        $scope.deleteDialog = function(proj) {
            $scope.proj = proj;
            $( "#dialog-confirm" ).dialog({
                resizable: false,
                height: 160,
                modal: true,
                buttons: {
                    Delete: function() {
                        $scope.$apply(function(){
                            $scope.deleteProject();
                            //if ( $scope.deleteProject()){
                                $scope.proj = null;
                                $scope.projpos = -1;
                                $scope.projForm.$setPristine();
                                $(".ui-dialog-content").dialog("close");
                                
                                $( "#dialog-ok-delete" ).dialog({
                                    resizable: false,
                                    height: 160,
                                    modal: true,
                                    buttons: {
                                        
                                        OK: function() {
                                            $( this ).dialog( "close" );
                                        }
                                    }
                                });
                            //}
                            // else{

                            //     $( "#dialog-delete-error" ).dialog({
                            //         resizable: false,
                            //         height: 160,
                            //         modal: true,
                            //         buttons: {
                                        
                            //             OK: function() {
                            //                 $( this ).dialog( "close" );
                            //             }
                            //         }
                            //     });


                            // }

                        });
                    },
                    
                    Cancel: function() {
                        $( this ).dialog( "close" );
                     
                    }
            }
        });
      };

    



    //go to project
    $scope.go = function(id){

        window.location.href = "file:///Users/valegnocca/Dropbox/TESI_VERA/implementazione_XML/proveXSL/methods1.xml?projectID=" + id;
    }








}

